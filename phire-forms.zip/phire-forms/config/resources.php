<?php

return [
    'forms' => [
        'index',
        'add',
        'edit',
        'manage',
        'copy',
        'remove'
    ],
    'submissions' => [
        'index',
        'export',
        'process'
    ]
];