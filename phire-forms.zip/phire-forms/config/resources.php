<?php

return [
    'forms' => [
        'index',
        'add',
        'edit',
        'remove'
    ],
    'submissions' => [
        'index',
        'export',
        'process'
    ]
];