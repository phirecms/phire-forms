<?php

return [
    'forms' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];