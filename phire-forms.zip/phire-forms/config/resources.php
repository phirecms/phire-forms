<?php

return [
    'forms' => [
        'index',
        'add',
        'edit',
        'copy',
        'remove'
    ],
    'submissions' => [
        'index',
        'export',
        'process'
    ]
];